package com.example.exp1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SecondActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout1);
    }
}