package com.example.exp3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button button_Login = (Button) findViewById(R.id.button_Login);
        button_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editName = (EditText) findViewById(R.id.editText_Name);
                EditText editPassword = (EditText) findViewById(R.id.editText_Password);
                String name = editName.getText().toString();
                String password = editPassword.getText().toString();
                if (name.equals("admin") && password.equals("admin")) {
                    Intent intent = new Intent(LoginActivity.this, SuccessActivity.class);
                    intent.putExtra("name", name);
                    intent.putExtra("password", password);
                    startActivity(intent);
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                    builder.setTitle("提示：");
                    builder.setMessage("用户名或者密码错误!");
                    builder.setIcon(R.mipmap.ic_launcher);
                    builder.setCancelable(true);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });
    }
}