package com.example.exp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.exp4.ssb.adapter.BrandAdapter;
import com.example.exp4.ssb.domain.Brand;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Brand> brandList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initBrands(); //初始化品牌数据
        BrandAdapter brandAdapter = new BrandAdapter(MainActivity.this, R.layout.brand_item, brandList);
        ListView listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(brandAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Brand brand = brandList.get(i);
                Intent intent = new Intent(MainActivity.this, ItemDetailActivity.class);
                intent.putExtra("brand", brand);
                startActivity(intent);
            }
        });
    }

    private void initBrands() {
        for (int i = 0; i < 1; i++) {
            Brand lenovo = new Brand(1, "联想", 510947);
            brandList.add(lenovo);
            Brand dale = new Brand(2, "戴尔", 225193);
            brandList.add(dale);
            Brand asus = new Brand(3, "华硕", 222513);
            brandList.add(asus);
            Brand apple = new Brand(4, "苹果", 181891);
            brandList.add(apple);
            Brand hp = new Brand(5, "惠普", 91470);
            brandList.add(hp);
        }
    }
}