package com.example.exp4.ssb.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.exp4.R;
import com.example.exp4.ssb.domain.Brand;

import java.util.List;

public class BrandAdapter extends ArrayAdapter<Brand> {
    private int resourceId;

    public BrandAdapter(@NonNull Context context, int textViewResourceId, @NonNull List<Brand> objects) {
        super(context, textViewResourceId, objects);
        resourceId = textViewResourceId;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Brand brand = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
        TextView brandRank = (TextView) view.findViewById(R.id.brand_rank);
        TextView brandName = (TextView) view.findViewById(R.id.brand_name);
        TextView brandIndex = (TextView) view.findViewById(R.id.brand_index);
        brandRank.setText(brand.getRank() + "");
        brandName.setText(brand.getName());
        brandIndex.setText(brand.getIndex() + "");
        if (brand.getRank() == 1) {
            brandRank.setBackgroundColor(Color.parseColor("#FF0000"));
        } else if (brand.getRank() == 2) {
            brandRank.setBackgroundColor(Color.parseColor("#EEEE00"));
        } else if (brand.getRank() == 3) {
            brandRank.setBackgroundColor(Color.parseColor("#EEEE00"));
        } else {
            brandRank.setBackgroundColor(Color.parseColor("#E0FFFF"));
        }
        return view;
    }
}
