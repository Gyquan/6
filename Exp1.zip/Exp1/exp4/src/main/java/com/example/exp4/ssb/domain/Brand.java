package com.example.exp4.ssb.domain;

import java.io.Serializable;

public class Brand implements Serializable {
    private int rank;
    private String name;
    private int index;

    public Brand(int rank, String name, int index) {
        this.rank = rank;
        this.name = name;
        this.index = index;
    }

    public int getRank() {
        return rank;
    }

    public String getName() {
        return name;
    }

    public int getIndex() {
        return index;
    }
}
