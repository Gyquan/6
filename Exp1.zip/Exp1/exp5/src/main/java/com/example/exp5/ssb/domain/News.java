package com.example.exp5.ssb.domain;

import java.io.Serializable;

public class News implements Serializable {

}
